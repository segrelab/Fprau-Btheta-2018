%Function to produce data for and complete an ANOVA to determine the effect
%of mono/coculutre conditions and different inital glucose/acetate
%concentrations on shape of butyrate production curves from experiment

function shapeANOVA( coBut ,fpMonoBut , g1 , g2 )

coAvgRate = [(coBut(7,2:4)-coBut(1,2:4))' (coBut(14,2:4)-coBut(8,2:4))' (coBut(21,2:4)-coBut(15,2:4))'];
fpAvgRate = [(fpMonoBut(7,2:4)-fpMonoBut(1,2:4))' (fpMonoBut(14,2:4)-fpMonoBut(8,2:4))' (fpMonoBut(21,2:4)-fpMonoBut(15,2:4))'];

for j = 2:6
    fpDev((j-1),:)=(fpMonoBut(j,2:4)-fpMonoBut((j-1),2:4))-(fpAvgRate(:,1)./12)';
end
%average rate of last bin must be determined using the bin size of 14
%rather than 2, i.e. num bins = (total time pd)/(last bin time pd) = 24/14
%= 1.74
fpDev(6,:)=(fpMonoBut(7,2:4)-fpMonoBut(6,2:4))-(fpAvgRate(:,1)./1.74)';

for j = 9:13
    fpDev(j-2,:)=(fpMonoBut(j,2:4)-fpMonoBut((j-1),2:4))-(fpAvgRate(:,2)./12)';
end

fpDev(12,:)=(fpMonoBut(14,2:4)-fpMonoBut(13,2:4))-(fpAvgRate(:,1)./1.74)';

for j = 16:20
    fpDev(j-3,:)=(fpMonoBut(j,2:4)-fpMonoBut((j-1),2:4))-(fpAvgRate(:,3)./12)';
end

fpDev(18,:)=(fpMonoBut(21,2:4)-fpMonoBut(20,2:4))-(fpAvgRate(:,1)./1.74)';

for j = 2:6
    coDev((j-1),:)=(coBut(j,2:4)-coBut((j-1),2:4))-(coAvgRate(:,1)./12)';
end

coDev(6,:)=(coBut(7,2:4)-coBut(6,2:4))-(coAvgRate(:,1)./1.74)';

for j = 9:14
    coDev(j-2,:)=(coBut(j,2:4)-coBut((j-1),2:4))-(coAvgRate(:,2)./12)';
end

coDev(12,:)=(coBut(14,2:4)-coBut(13,2:4))-(coAvgRate(:,2)./1.74)';

for j = 16:21
    coDev(j-3,:)=(coBut(j,2:4)-coBut((j-1),2:4))-(coAvgRate(:,3)./12)';
end

coDev(18,:)=(coBut(21,2:4)-coBut(20,2:4))-(coAvgRate(:,2)./1.74)';

coDevData = [];
fpDevData = [];
for j = 1:length(coDev(:,1))
    coDevData = [coDevData coDev(j,:)];
    fpDevData = [fpDevData fpDev(j,:)];
end
devData = [fpDevData coDevData];
p = anovan(devData,{g1 g2,},'model','interaction','varnames',{'initial glc/ac','mono/co'});