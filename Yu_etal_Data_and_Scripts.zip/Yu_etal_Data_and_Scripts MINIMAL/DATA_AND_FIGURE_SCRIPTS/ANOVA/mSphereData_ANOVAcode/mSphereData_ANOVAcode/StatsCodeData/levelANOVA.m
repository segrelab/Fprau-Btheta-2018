
%Function to produce data for and complete an ANOVA to determine the effect
%of mono/coculutre conditions and different inital glucose/acetate
%concentrations on level of butyrate production curves from experiment

function levelANOVA( coBut ,fpMonoBut , q1 , q2 )

avgRateFp = [((fpMonoBut(7,2:4)-fpMonoBut(1,2:4)))' ((fpMonoBut(14,2:4)-fpMonoBut(8,2:4)))' ((fpMonoBut(21,2:4)-fpMonoBut(15,2:4)))'];
avgRateCo = [((coBut(7,2:4)-coBut(1,2:4)))' ((coBut(14,2:4)-coBut(8,2:4)))' ((coBut(21,2:4)-coBut(15,2:4)))'];

% avgRateFp = [((fpMonoBut(7,2)-fpMonoBut(1,2)))' ((fpMonoBut(14,2)-fpMonoBut(8,2)))' ((fpMonoBut(21,2)-fpMonoBut(15,2)))'];
% avgRateCo = [((coBut(7,2)-coBut(1,2)))' ((coBut(14,2)-coBut(8,2)))' ((coBut(21,2)-coBut(15,2)))'];

avgRateFpMonoVec = [ avgRateFp(:,1)./12 ; avgRateFp(:,2)./12 ; avgRateFp(:,3)./12 ];
avgRateCoVec = [ avgRateCo(:,1)./12 ; avgRateCo(:,2)./12 ; avgRateCo(:,3)./12 ];

avgRateManova = [ avgRateFpMonoVec ; avgRateCoVec ];

p = anovan(avgRateManova,{q1 q2},'model','interaction','varnames',{'initial glc/ac','mono/co'});