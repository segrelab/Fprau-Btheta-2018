getwd()
setwd("Z:/dukovski/Work/LLCollaboration/Experimental_Results_02282018/IlijaDataPlots")
dg <- read.table("20180201 MS OD data.txt",header = FALSE)
#tiff(filename="ODplot_sim_exp_FpV23_coculture_species.tiff", width = 8, height = 6 , units = 'in', res = 1000)

library(ggplot2)
library(gtable)
sdev_min=0.02
n_points=5
dof=n_points-1

RMSE<-matrix(0,ncol=3,nrow=3)
sim_points<-c(0,200,400,600,800,1000,2400)

#############################################################
Alow=dg[seq(1,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
ymean=0
mydata=0
for(i in c(1:7)){
	xx[i]=Alow[i,1]
	yy[1]=Alow[i,2]
	yy[2]=Alow[i,3]
	yy[3]=Alow[i,4]
	yrmse[i,1]=yy[1]
	yrmse[i,2]=yy[2]
	yrmse[i,3]=yy[3]
	ymean[i]=mean(yy)
	sdev[i]=sd(yy)
	if(sdev[i]<sdev_min){sdev[i]=sdev_min}
	}
mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataAl=data.frame(mydata1)
colnames(mydataAl)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataAl$Species <- rep("Coculture",length(list1))
mydataAl$Media <- rep("Low",length(list1))
mydata<-mydataAl


Al_sim <-read.table("SimulationResults_March2018/Final_FpV23/Co_low_totalbiomass_NOLIMITS_K01_r236.txt",header = FALSE)
x <- Al_sim[,1]
y <- Al_sim[,2]+Al_sim[,3]
z <- Al_sim[,2]
w <- Al_sim[,3]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim2=data.frame(mydata2)
colnames(mydata_sim2)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim2$Species <- rep("Coculture",length(list1))
mydata_sim2$Media <- rep("Low",length(list1))
mydata_sim<-mydata_sim2

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[1,1]=sqrt(SE/21)



##############################################################################################


Amid=dg[seq(2,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Amid[i,1]
yy[1]=Amid[i,2]
yy[2]=Amid[i,3]
yy[3]=Amid[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataAm=data.frame(mydata1)
colnames(mydataAm)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataAm$Species <- rep("Coculture",length(list1))
mydataAm$Media <- rep("Medium",length(list1))
mydata<-merge(mydata,mydataAm, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)


Am_sim <-read.table("SimulationResults_March2018/Final_FpV23/Co_med_totalbiomass_NOLIMITS_K01_r236.txt",header = FALSE)
x <- Am_sim[,1]
y <- Am_sim[,2]+Am_sim[,3]
z <- Am_sim[,2]
w <- Am_sim[,3]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("Coculture",length(list1))
mydata_sim1$Media <- rep("Medium",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[1,2]=sqrt(SE/21)


##############################################################################


Ahigh=dg[seq(3,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Ahigh[i,1]
yy[1]=Ahigh[i,2]
yy[2]=Ahigh[i,3]
yy[3]=Ahigh[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataAh=data.frame(mydata1)
colnames(mydataAh)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataAh$Species <- rep("Coculture",length(list1))
mydataAh$Media <- rep("High",length(list1))


Ah_sim <-read.table("SimulationResults_March2018/Final_FpV23/Co_high_totalbiomass_NOLIMITS_K01_r236.txt",header = FALSE)
x <- Ah_sim[,1]
y <- Ah_sim[,2]+Ah_sim[,3]
z <- Ah_sim[,2]
w <- Ah_sim[,3]

mydata<-merge(mydataAm,mydataAl, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)
mydata<-merge(mydata,mydataAh, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)
#mydata$Media_f=factor(mydata$Media,levels=c("Low","Medium","High"))

#g<-ggplot(mydata,aes(Time,OD))+geom_point(aes(x=Time,y=OD))+geom_errorbar(aes(ymin=OD-SDEV, ymax=OD+SDEV),width=0.5)+facet_grid(Species ~ Media_f )

#g<-ggplotly(g)

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("Coculture",length(list1))
mydata_sim1$Media <- rep("High",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[1,3]=sqrt(SE/21)


######################################################################################

Blow=dg[seq(4,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Blow[i,1]
yy[1]=Blow[i,2]
yy[2]=Blow[i,3]
yy[3]=Blow[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataBl=data.frame(mydata1)
colnames(mydataBl)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataBl$Species <- rep("B. thetaiotaomicron",length(list1))
mydataBl$Media <- rep("Low",length(list1))
mydata<-merge(mydata,mydataBl, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)

Bl_sim <-read.table("SimulationResults_March2018/Final_FpV23/Btheta_low_totalbiomass_NOLIMITS.txt",header = FALSE)
x <- Bl_sim[,1]
y <- Bl_sim[,2]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("B. thetaiotaomicron",length(list1))
mydata_sim1$Media <- rep("Low",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[2,1]=sqrt(SE/21)


############################################################################################


Bmid=dg[seq(5,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Bmid[i,1]
yy[1]=Bmid[i,2]
yy[2]=Bmid[i,3]
yy[3]=Bmid[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataBm=data.frame(mydata1)
colnames(mydataBm)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataBm$Species <- rep("B. thetaiotaomicron",length(list1))
mydataBm$Media <- rep("Medium",length(list1))
mydata<-merge(mydata,mydataBm, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)

Bm_sim <-read.table("SimulationResults_March2018/Final_FpV23/Btheta_med_totalbiomass_NOLIMITS.txt",header = FALSE)
x <- Bm_sim[,1]
y <- Bm_sim[,2]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("B. thetaiotaomicron",length(list1))
mydata_sim1$Media <- rep("Medium",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[2,2]=sqrt(SE/21)


############################################################################################


Bhigh=dg[seq(6,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Bhigh[i,1]
yy[1]=Bhigh[i,2]
yy[2]=Bhigh[i,3]
yy[3]=Bhigh[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataBh=data.frame(mydata1)
colnames(mydataBh)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataBh$Species <- rep("B. thetaiotaomicron",length(list1))
mydataBh$Media <- rep("High",length(list1))
mydata<-merge(mydata,mydataBh, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)

Bh_sim <-read.table("SimulationResults_March2018/Final_FpV23/Btheta_high_totalbiomass_NOLIMITS.txt",header = FALSE)
x <- Bh_sim[,1]
y <- Bh_sim[,2]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("B. thetaiotaomicron",length(list1))
mydata_sim1$Media <- rep("High",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[2,3]=sqrt(SE/21)


###########################################################################################


Clow=dg[seq(7,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Clow[i,1]
yy[1]=Clow[i,2]
yy[2]=Clow[i,3]
yy[3]=Clow[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataCl=data.frame(mydata1)
colnames(mydataCl)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataCl$Species <- rep("F. prausnitzii",length(list1))
mydataCl$Media <- rep("Low",length(list1))
mydata<-merge(mydata,mydataCl, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)

Cl_sim <-read.table("SimulationResults_March2018/Final_FpV23/Fp_low_totalbiomass_K0.01.txt",header = FALSE)
x <- Cl_sim[,1]
y <- Cl_sim[,3]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("F. prausnitzii",length(list1))
mydata_sim1$Media <- rep("Low",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[3,1]=sqrt(SE/21)


#############################################################################################


Cmid=dg[seq(8,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
stdev=0
for(i in c(1:7)){
xx[i]=Cmid[i,1]
yy[1]=Cmid[i,2]
yy[2]=Cmid[i,3]
yy[3]=Cmid[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
stdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}
mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataCm=data.frame(mydata1)
colnames(mydataCm)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataCm$Species <- rep("F. prausnitzii",length(list1))
mydataCm$Media <- rep("Medium",length(list1))
mydata<-merge(mydata,mydataCm, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)

Cm_sim <-read.table("SimulationResults_March2018/Final_FpV23/Fp_med_totalbiomass_K0.01.txt",header = FALSE)
x <- Cm_sim[,1]
y <- Cm_sim[,3]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("F. prausnitzii",length(list1))
mydata_sim1$Media <- rep("Medium",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[3,2]=sqrt(SE/21)


#########################################################################################


Chigh=dg[seq(9,63,by=9),]
xx=0
yy=0
yrmse<-matrix(0,ncol=3,nrow=7)
sdev=0
for(i in c(1:7)){
xx[i]=Chigh[i,1]
yy[1]=Chigh[i,2]
yy[2]=Chigh[i,3]
yy[3]=Chigh[i,4]
yrmse[i,1]=yy[1]
yrmse[i,2]=yy[2]
yrmse[i,3]=yy[3]
ymean[i]=mean(yy)
sdev[i]=sd(yy)
if(sdev[i]<sdev_min){sdev[i]=sdev_min}
}

mydata1<-matrix(c(xx,ymean,sdev),ncol=3)
mydataCh=data.frame(mydata1)
colnames(mydataCh)<- c("Time","OD","SDEV")
list1 <- 1:7
mydataCh$Species <- rep("F. prausnitzii",length(list1))
mydataCh$Media <- rep("High",length(list1))
mydata<-merge(mydata,mydataCh, by=c("Time","Species","Media","OD","SDEV"),all=TRUE)

Ch_sim <-read.table("SimulationResults_March2018/Final_FpV23/Fp_high_totalbiomass_K0.01.txt",header = FALSE)
x <- Ch_sim[,1]
y <- Ch_sim[,3]

mydata2<-matrix(c(x,y),ncol=2)
mydata_sim1=data.frame(mydata2)
colnames(mydata_sim1)<- c("Time","OD")
list1 <- 1:length(x)
mydata_sim1$Species <- rep("F. prausnitzii",length(list1))
mydata_sim1$Media <- rep("High",length(list1))
mydata_sim<-merge(mydata_sim,mydata_sim1, by=c("Time","Species","Media","OD"),all=TRUE)

SE=0
for(i in c(1:7)){
	for(j in c(1:3)){
		SE=SE+(yrmse[i,j]-1000*y[sim_points[i]+1]/(0.36*5))^2
		}
	}
RMSE[3,3]=sqrt(SE/21)


##################################################################################

mydata$Media_f=factor(mydata$Media,levels=c("Low","Medium","High"))
mydata$Species_f=factor(mydata$Species,levels=c("Coculture","B. thetaiotaomicron","F. prausnitzii"))

mydata_sim$Media_f=factor(mydata_sim$Media,levels=c("Low","Medium","High"))
mydata_sim$Species_f=factor(mydata_sim$Species,levels=c("Coculture","B. thetaiotaomicron","F. prausnitzii"))


g<-ggplot(mydata,aes(Time,OD))+geom_point(data=mydata,aes(x=Time,y=OD),color="#009999",size=1.7)+geom_errorbar(aes(ymin=OD-SDEV, ymax=OD+SDEV),width=1.0,color="#009999")+geom_line(data=mydata_sim,aes(x=0.01*Time,y=1000*OD/(5*0.36)),size=0.6)+xlim(0,25)+ylim(0,1.5)+xlab("Time [h]")+ylab(expression("OD"[600]))+facet_grid(Species_f ~ Media_f )+theme_bw(base_size=15)

#g<-ggplot(mydata_sim,aes(x=Time*0.01,y=1000*OD/(5*0.36)))+geom_line(aes(x=0.01*Time,y=1000*OD/(5*0.36)))+facet_grid(Species_f ~ Media_f )

#g<-ggplot()+geom_line(data=mydata_sim,aes(x=Time,y=OD))+xlim(0,25)+ylim(0,1.5)+facet_grid(Species_f ~ Media_f )



plot(g)
ggsave(file="OD_plot_ggplot.png")

